from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set options to exclude DevTools logging
options = Options()
options.add_experimental_option("excludeSwitches", ["enable-logging"])

class Signup:

    def __init__(self):
        self.email = "deepikatester@mentorfriends.com"
        self.username = "deepika"
        self.password = "freeschema"
        self.firstname = "Recag"
        self.lastname = "Avastu"
        self.signup_url = "https://boomconsole.com/signup"
        self.success_url = "https://boomconsole.com/login"  # Adjust as needed
        self.driver = webdriver.Chrome(options=options)

    def signup_web(self):
        print("Signup Testing started from WEB")

        try:
            self.driver.get(self.signup_url)
            print("Navigated to signup page")

            # Fill in the "Type" dropdown
            type_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//select[@formcontrolname="type"]'))
            )
            type_field.send_keys("person")  # Adjust the type value as necessary

            # Fill in the "Username" field
            username_field = self.driver.find_element(By.XPATH, '//input[@formcontrolname="username"]')
            username_field.send_keys(self.username)

            # Fill in the "Email address" field
            email_field = self.driver.find_element(By.XPATH, '//input[@formcontrolname="emailaddress"]')
            email_field.send_keys(self.email)

            # Click the "Next" button
            next_button = self.driver.find_element(By.XPATH, '//button[@type="submit"]')
            next_button.click()

            # Wait for the additional fields to be visible
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//input[@formcontrolname="firstname"]'))
            )

            # Fill in the "First Name" field
            firstname_field = self.driver.find_element(By.XPATH, '//input[@formcontrolname="firstname"]')
            firstname_field.send_keys(self.firstname)

            # Fill in the "Last Name" field
            lastname_field = self.driver.find_element(By.XPATH, '//input[@formcontrolname="lastname"]')
            lastname_field.send_keys(self.lastname)

            # Fill in the "Gender title" dropdown
            title_field = self.driver.find_element(By.XPATH, '//select[@formcontrolname="title"]')
            title_field.send_keys("Mr.")  # Adjust the title value as necessary

            # Fill in the "Password" field
            password_field = self.driver.find_element(By.XPATH, '//input[@formcontrolname="password"]')
            password_field.send_keys(self.password)

            # Fill in the "Confirm Password" field
            confirm_password_field = self.driver.find_element(By.XPATH, '//input[@formcontrolname="confirmPassword"]')
            confirm_password_field.send_keys(self.password)

            # Agree to the terms and conditions
            agree_terms_checkbox = self.driver.find_element(By.XPATH, '//input[@formcontrolname="agreeTerms"]')
            agree_terms_checkbox.click()

            # Click the "Submit" button
            submit_button = self.driver.find_element(By.XPATH, '//button[@type="submit"]')
            submit_button.click()

            # Wait for the success URL
            WebDriverWait(self.driver, 10).until(EC.url_contains(self.success_url))
            print("Signup successful, current URL:", self.driver.current_url)

            # Extract any tokens or confirmation messages from local storage
            profile_data = self.extract_tokens_from_local_storage()
            print("Profile data:", profile_data)

        except Exception as e:
            print("An error occurred during signup:", e)  

        finally:
            # Close the browser
            self.driver.quit()
            print("Testing completed")

    def extract_tokens_from_local_storage(self):
        try:
            # Execute JavaScript to retrieve the access token from local storage
            profile = self.driver.execute_script("return localStorage.getItem('profile');")  # Adjust key as needed
            return profile
        except Exception as e:
            print("An error occurred while extracting tokens:", e)

if __name__ == "__main__":
    signup_test_instance = Signup()
    signup_test_instance.signup_web()
